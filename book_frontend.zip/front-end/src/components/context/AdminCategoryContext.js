import { createContext } from "react";

export const AdminCategoryContext = createContext({});