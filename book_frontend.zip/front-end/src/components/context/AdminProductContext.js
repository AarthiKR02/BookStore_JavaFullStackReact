import { createContext } from "react";

export const AdminProductContext = createContext([]);