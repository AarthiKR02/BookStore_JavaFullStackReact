// Importing necessary React hooks and context
import React from 'react';
import { useContext } from 'react';
import { useState } from 'react';
import { AdminCategoryContext } from '../../context/AdminCategoryContext';
import { useNavigate } from 'react-router';
// Importing SweetAlert2 for alert dialogs
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content'; 
// Importing custom axios instance for API calls
import { axiosInstance } from '../../../util/axiosInstance';

// Component for adding a new category
const AddCategory = () => 
{
    // Initialize SweetAlert2 with React content
    const mySwal = withReactContent(Swal);

// Destructuring setCategories function from context
    const {setCategories} = useContext(AdminCategoryContext);

    // State to hold the details of the new category
    const [categoryDetail,setCategoryDetail] = useState({
        name:''
    });

    // Hook to navigate programmatically
    const navigate = useNavigate();

    // Handler for input changes, updates the categoryDetail state
    const handleChange = (e) =>{
        setCategoryDetail((prevData) => ({...prevData,[e.target.name]:e.target.value}));
    }

     // Handler for form submission
    const handleSubmit = async (e) =>{
        e.preventDefault();
        try{
             // API call to create a new category
            const response = await axiosInstance.post('book-category/create',categoryDetail);
            if(response.status === 200){
                console.log(response.data);
                 // Update the categories state in context
                setCategories((prevState) => ([...prevState,response.data]));
                mySwal.fire({
                    icon: 'success',
                    title: 'Success',
                    text:"Category is created!",
                })
                // Navigate to the all-categories route
                navigate('/all-categories');
            }
        } catch(err){
            mySwal.fire({
                icon: 'error',
                title: 'Oops...',
                text: "Something went wrong's",
            })
        }
    }  

    return (
        <div className="card">
            <div className="card-body">
                <h5 className="card-title">Add Category</h5>
                <form className="row g-3" onSubmit={handleSubmit}>
                    <div className="col-md-12">
                        <label htmlFor="inputName5" className="form-label">Category Name</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            name="name"
                            id="inputName5"
                            value={categoryDetail.name}
                            onChange={handleChange} />
                    </div>
                    <div className="text-center">
                        <button type="submit" className="btn btn-main px-3 mx-3">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    )
}
// Exporting the component for use in other parts of the application
export default AddCategory
