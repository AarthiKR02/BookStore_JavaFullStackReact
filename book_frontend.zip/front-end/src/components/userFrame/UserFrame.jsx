import React, { useContext, useEffect, useState } from 'react';
import {Routes, Route, Navigate} from 'react-router-dom';
import Navbar from '../navbar/Navbar';
import Footer from '../footer/Footer';
import Home from '../home/Home';
import Cart from '../cart/Cart';
import Dashboard from '../dashboard/Dashboard';
import { LoginContext } from '../context/LoginContext';
import { ProductContext } from '../context/ProductContext';
import { CategoryContext } from '../context/CategoryContext';
import { CartContext } from '../context/CartContext';
import axios from 'axios';
import withReactContent from 'sweetalert2-react-content';
import Swal from 'sweetalert2';
import Product from '../product/Product';
import { axiosInstance } from '../../util/axiosInstance';



const UserFrame = () => {
  const {user} = useContext(LoginContext);
  const [products,setProducts] = useState([]);
  const [categories,setCategories] = useState();
  const [cart,setCart] = useState({});
  const MySwal = withReactContent(Swal);

  const getCart = async (e) =>{
    const response = await axiosInstance.get('cart/user-id/'+ user.id);
    if(response.status === 200){
      setCart(response.data);
    }else{
        MySwal.fire({
          icon:'error',
          title:'Opps...',
          text:"Something Went Wrong!"
        });
    }
  }

  useEffect(() =>{
    if(user !== null){
      getCart();
    }
    // eslint-disable-next-line
  },[user]);

  return (
    <>
        <ProductContext.Provider value={{products,setProducts}}>
          <CategoryContext.Provider value={{categories,setCategories}}>
            <CartContext.Provider value={{cart,setCart}}>
              <Navbar />
              <Routes>
                  <Route path='/' exact element={<Navigate to="/home" />} />
                  <Route path='/home' element={<Home />} />
                  <Route path='/product/:id' element={<Product />} />
                  <Route path='/cart' element={<Cart />} />
                  <Route path='/dashboard' element={<Dashboard />} />
                  <Route path='*' exact element={<Home />} />
              </Routes>
              <Footer />
            </CartContext.Provider>
          </CategoryContext.Provider>
        </ProductContext.Provider>
    </>
  )
}

export default UserFrame;
