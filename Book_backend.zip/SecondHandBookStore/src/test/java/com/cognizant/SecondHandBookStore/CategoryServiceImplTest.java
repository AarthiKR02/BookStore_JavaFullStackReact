package com.cognizant.SecondHandBookStore;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cognizant.SecondHandBookStore.entity.Category;
import com.cognizant.SecondHandBookStore.exception.CategoryNotFoundException;
import com.cognizant.SecondHandBookStore.repository.CategoryRepository;
import com.cognizant.SecondHandBookStore.service.CategoryServiceImpl;

public class CategoryServiceImplTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    private Category category1;
    private Category category2;
    private List<Category> categories;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);

        category1 = new Category();
        category1.setId(1L);
        category1.setName("Category 1");

        category2 = new Category();
        category2.setId(2L);
        category2.setName("Category 2");

        categories = new ArrayList<>();
        categories.add(category1);
        categories.add(category2);
    }

    @Test
    public void testGetCategories() {
        when(categoryRepository.findAll()).thenReturn(categories);

        List<Category> result = categoryService.getCategories();

        assertEquals(categories, result);
        verify(categoryRepository, times(1)).findAll();
    }

    @Test
    public void testGetCategory() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.of(category1));

        Category result = categoryService.getCategory(1L);

        assertEquals(category1, result);
        verify(categoryRepository, times(1)).findById(anyLong());
    }

    @Test
    public void testGetCategoryNotFoundException() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(CategoryNotFoundException.class, () -> categoryService.getCategory(1L));
        verify(categoryRepository, times(1)).findById(anyLong());
    }

    @Test
    public void testCreateCategory() {
        when(categoryRepository.save(any(Category.class))).thenReturn(category1);

        Category result = categoryService.createCategory(category1);

        assertEquals(category1, result);
        verify(categoryRepository, times(1)).save(any(Category.class));
    }

    @Test
    public void testUpdateCategory() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.of(category1));
        when(categoryRepository.save(any(Category.class))).thenReturn(category1);

        Category result = categoryService.updateCategory(1L, category2);

        assertEquals(category1, result);
        verify(categoryRepository, times(1)).findById(anyLong());
        verify(categoryRepository, times(1)).save(any(Category.class));
    }

    @Test
    public void testUpdateCategoryNotFoundException() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(CategoryNotFoundException.class, () -> categoryService.updateCategory(1L, category2));
        verify(categoryRepository, times(1)).findById(anyLong());
        verify(categoryRepository, never()).save(any(Category.class));
    }

    @Test
    public void testDeleteCategory() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.of(category1));

        String result = categoryService.deleteCategory(1L);

        assertEquals("Category 1 is Deleted", result);
        verify(categoryRepository, times(1)).findById(anyLong());
        verify(categoryRepository, times(1)).delete(any(Category.class));
    }

    @Test
    public void testDeleteCategoryNotFoundException() {
        when(categoryRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(CategoryNotFoundException.class, () -> categoryService.deleteCategory(1L));
        verify(categoryRepository, times(1)).findById(anyLong());
        verify(categoryRepository, never()).delete(any(Category.class));
    }
}