package com.cognizant.SecondHandBookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondHandBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
