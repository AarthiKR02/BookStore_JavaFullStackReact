package com.cognizant.SecondHandBookStore;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognizant.SecondHandBookStore.entity.Cart;
import com.cognizant.SecondHandBookStore.entity.CartItem;
import com.cognizant.SecondHandBookStore.entity.Product;
import com.cognizant.SecondHandBookStore.entity.User;
import com.cognizant.SecondHandBookStore.exception.ProductAlreadyExistException;
import com.cognizant.SecondHandBookStore.exception.ProductOutOfStockException;
import com.cognizant.SecondHandBookStore.repository.CartItemRepository;
import com.cognizant.SecondHandBookStore.repository.CartRepository;
import com.cognizant.SecondHandBookStore.responseAndRequest.CartRequest;
import com.cognizant.SecondHandBookStore.service.CartServiceImpl;
import com.cognizant.SecondHandBookStore.service.ProductService;
import com.cognizant.SecondHandBookStore.service.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TestCartServiceImpl {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private ProductService productService;

    @Mock
    private UserService userService;

    @InjectMocks
    private CartServiceImpl cartService;

    private Cart cart;
    private CartItem cartItem;
    private Product product;
    private User user;

    @BeforeEach
    public void setup() {
        cart = new Cart();
        cartItem = new CartItem();
        product = new Product();
        user = new User();

        cart.setId(1L);
        cart.setUser(user);
        cart.setCartItems(new ArrayList<>());

        cartItem.setId(1L);
        cartItem.setQuantity(1);
        cartItem.setCart(cart);
        cartItem.setProduct(product);

        product.setId(1L);
        product.setSellPrice(10);
        product.setStock(10);

        user.setId(1L);
    }

    @Test
    public void testGetCart() {
        when(cartRepository.findById(1L)).thenReturn(Optional.of(cart));

        Cart result = cartService.getCart(1L);

        assertEquals(cart, result);
        verify(cartRepository, times(1)).findById(1L);
    }

    @Test
    public void testGetCartByUser() {
        when(cartRepository.findByUserId(1L)).thenReturn(cart);

        Cart result = cartService.getCartByUser(1L);

        assertEquals(cart, result);
        verify(cartRepository, times(1)).findByUserId(1L);
    }

//    @Test
//    public void testAddCartItem() throws ProductAlreadyExistException, ProductOutOfStockException {
//        when(productService.getProduct(1L)).thenReturn(product);
//        when(userService.getUser(1L)).thenReturn(user);
//        when(cartRepository.findByUserId(1L)).thenReturn(cart);
//
//        CartRequest cartRequest = new CartRequest();
//        cartRequest.setProductId(1L);
//        cartRequest.setQuantity(1);
//        cartRequest.setUserId(1L);
//
//        Cart result = cartService.addCartItem(cartRequest);
//
//        assertEquals(cart, result);
//        verify(productService, times(1)).getProduct(1L);
//        verify(userService, times(1)).getUser(1L);
//        verify(cartRepository, times(1)).findByUserId(1L);
//        verify(cartItemRepository, times(1)).save(cartItem);
//        verify(cartRepository, times(1)).save(cart);
//    }

    @Test
    public void testAddCartItemProductAlreadyExistException() {
        when(productService.getProduct(1L)).thenReturn(product);
        when(userService.getUser(1L)).thenReturn(user);
        when(cartRepository.findByUserId(1L)).thenReturn(cart);

        cart.getCartItems().add(cartItem);

        CartRequest cartRequest = new CartRequest();
        cartRequest.setProductId(1L);
        cartRequest.setQuantity(1);
        cartRequest.setUserId(1L);

        assertThrows(ProductAlreadyExistException.class, () -> cartService.addCartItem(cartRequest));

        verify(productService, times(1)).getProduct(1L);
        verify(userService, times(1)).getUser(1L);
        verify(cartRepository, times(1)).findByUserId(1L);
        verifyNoMoreInteractions(cartItemRepository);
        verifyNoMoreInteractions(cartRepository);
    }

    @Test
    public void testAddCartItemProductOutOfStockException() {
        product.setStock(0);

        when(productService.getProduct(1L)).thenReturn(product);
        when(userService.getUser(1L)).thenReturn(user);
        when(cartRepository.findByUserId(1L)).thenReturn(cart);

        CartRequest cartRequest = new CartRequest();
        cartRequest.setProductId(1L);
        cartRequest.setQuantity(1);
        cartRequest.setUserId(1L);

        assertThrows(ProductOutOfStockException.class, () -> cartService.addCartItem(cartRequest));

        verify(productService, times(1)).getProduct(1L);
        verify(userService, times(1)).getUser(1L);
        verify(cartRepository, times(1)).findByUserId(1L);
        verifyNoMoreInteractions(cartItemRepository);
        verifyNoMoreInteractions(cartRepository);
    }

//    @Test
//    public void testIncreaseQuantity() throws ProductOutOfStockException {
//        when(productService.getProduct(1L)).thenReturn(product);
//        when(userService.getUser(1L)).thenReturn(user);
//        when(cartRepository.findByUserId(1L)).thenReturn(cart);
//        when(cartItemRepository.findByCartIdAndProductId(1L, 1L)).thenReturn(cartItem);
//
//        Cart result = cartService.increaseQuantity(1L, 1L);
//
//        assertEquals(cart, result);
//        assertEquals(2, cartItem.getQuantity());
//        verify(productService, times(1)).getProduct(1L);
//        verify(userService, times(1)).getUser(1L);
//        verify(cartRepository, times(1)).findByUserId(1L);
//        verify(cartItemRepository, times(1)).findByCartIdAndProductId(1L, 1L);
//        verify(cartItemRepository, times(1)).save(cartItem);
//        verify(cartRepository, times(1)).save(cart);
//    }

    @Test
    public void testIncreaseQuantityProductOutOfStockException() {
        product.setStock(1);

        when(productService.getProduct(1L)).thenReturn(product);
        when(userService.getUser(1L)).thenReturn(user);
        when(cartRepository.findByUserId(1L)).thenReturn(cart);
        when(cartItemRepository.findByCartIdAndProductId(1L, 1L)).thenReturn(cartItem);

        assertThrows(ProductOutOfStockException.class, () -> cartService.increaseQuantity(1L, 1L));

        verify(productService, times(1)).getProduct(1L);
        verify(userService, times(1)).getUser(1L);
        verify(cartRepository, times(1)).findByUserId(1L);
        verify(cartItemRepository, times(1)).findByCartIdAndProductId(1L, 1L);
        verifyNoMoreInteractions(cartItemRepository);
        verifyNoMoreInteractions(cartRepository);
    }

//    @Test
//    public void testDecreaseQuantity() {
//        when(productService.getProduct(1L)).thenReturn(product);
//        when(userService.getUser(1L)).thenReturn(user);
//        when(cartRepository.findByUserId(1L)).thenReturn(cart);
//        when(cartItemRepository.findByCartIdAndProductId(1L, 1L)).thenReturn(cartItem);
//
//        Cart result = cartService.decreaseQuantity(1L, 1L);
//
//        assertEquals(cart, result);
//        assertEquals(0, cartItem.getQuantity());
//        verify(productService, times(1)).getProduct(1L);
//        verify(userService, times(1)).getUser(1L);
//        verify(cartRepository, times(1)).findByUserId(1L);
//        verify(cartItemRepository, times(1)).findByCartIdAndProductId(1L, 1L);
//        verify(cartItemRepository, times(1)).save(cartItem);
//        verify(cartRepository, times(1)).save(cart);
//    }

//    @Test
//    public void testRemoveProduct() {
//        when(productService.getProduct(1L)).thenReturn(product);
//        when(userService.getUser(1L)).thenReturn(user);
//        when(cartRepository.findByUserId(1L)).thenReturn(cart);
//        when(cartItemRepository.findByCartIdAndProductId(1L, 1L)).thenReturn(cartItem);
//
//        Cart result = cartService.removeProduct(1L, 1L);
//
//        assertEquals(cart, result);
//        assertEquals(0,cart.getCartItems().size());
//        verify(productService, times(1)).getProduct(1L);
//        verify(userService, times(1)).getUser(1L);
//        verify(cartRepository, times(1)).findByUserId(1L);
//        verify(cartItemRepository, times(1)).findByCartIdAndProductId(1L, 1L);
//        verify(cartItemRepository, times(1)).delete(cartItem);
//        verify(cartRepository, times(1)).save(cart);
//    }
}