package com.cognizant.SecondHandBookStore;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.cognizant.SecondHandBookStore.entity.Cart;
import com.cognizant.SecondHandBookStore.entity.User;
import com.cognizant.SecondHandBookStore.exception.UserNotFoundException;
import com.cognizant.SecondHandBookStore.repository.CartRepository;
import com.cognizant.SecondHandBookStore.repository.UserRepository;
import com.cognizant.SecondHandBookStore.responseAndRequest.UserRequest;import com.cognizant.SecondHandBookStore.responseAndRequest.UserResponse;
import com.cognizant.SecondHandBookStore.service.UserServiceImpl;
import com.cognizant.SecondHandBookStore.util.JwtUtil;

public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private CartRepository cartRepository;
    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetUser() {
        User user = new User();
        user.setId(1L);
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));

        User result = userService.getUser(1L);

        assertEquals(user, result);
    }

    @Test
    public void testGetUserByEmail() {
        User user = new User();
        user.setEmail("test@example.com");
        when(userRepository.findByEmail(anyString())).thenReturn(user);

        User result = userService.getUserByEmail("test@example.com");

        assertEquals(user, result);
    }

//    @Test
//    public void testLogin() {
//        User user = new User();
//        user.setEmail("test@example.com");
//        user.setPassword("password");
//        UserRequest userRequest = new UserRequest();
//        userRequest.setEmail("test@example.com");
//        userRequest.setPassword("password");
//        String token = "token";
//        when(userRepository.findByEmail(anyString())).thenReturn(user);
//        when(jwtUtil.generateToken(anyString(), any())).thenReturn(token);
//        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
//
//        UserResponse result = userService.login(userRequest);
//
//        assertEquals(token, result.getToken());
//        assertEquals(user, result.getUser());
//    }

    @Test
    public void testCreateUser() {
//        User user = new User();
//        user.setId(1L);
        User userRequest = new User();
        userRequest.setId(1L);
        userRequest.setName("Test User");
        userRequest.setEmail("test@example.com");
        userRequest.setPassword("password");
        userRequest.setPhoneNo("1234567890");
        userRequest.setAddress("Test Address");
        String encryptedPassword = "encryptedPassword";
        when(userRepository.save(any(User.class))).thenReturn(userRequest);
        when(passwordEncoder.encode(anyString())).thenReturn(encryptedPassword);

        User result = userService.createUser(userRequest);

        assertEquals(userRequest, result);
        assertEquals("Test User", result.getName());
        assertEquals("test@example.com", result.getEmail());
        assertEquals(encryptedPassword, result.getPassword());
        assertEquals("1234567890", result.getPhoneNo());
        assertEquals("Test Address", result.getAddress());
    }

  

//    @Test
//  
//    public void testUpdateUser() {
//        // Initialize original user
//        User user = new User();
//        user.setId(1L);
//        user.setName("Test User1");
//        user.setEmail("test@example.com");
//        user.setPhoneNo("1234567890");
//        user.setAddress("Test Address");
//
//        // Initialize user request with updated details
//        User userRequest = new User();
//        userRequest.setName("Test User1");
//        userRequest.setEmail("test@example.com");
//        userRequest.setPhoneNo("1234567890");
//        userRequest.setAddress("Test Address");
//
//        // Mock repository to return original user
//        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
//
//        // Invoke updateUser with the updated details
//        User result = userService.updateUser(1L, userRequest);
//
//        // Assertions
//        assertEquals(userRequest.getEmail(), result.getEmail());
//        assertEquals(userRequest.getPhoneNo(), result.getPhoneNo());
//        assertEquals(userRequest.getAddress(), result.getAddress());
//        assertEquals(user.getName(), result.getName()); // Name should remain unchanged
//    }

    
    
    
    
    
    @Test
    public void testDeleteUser() {
        User user = new User();
        user.setId(1L);
        Cart cart = new Cart();
        cart.setUser(user);
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        doNothing().when(userRepository).deleteById(anyLong());
        doNothing().when(cartRepository).delete(any(Cart.class));

        String result = userService.deleteUser(1L);

        assertEquals("User 1 is Deleted!", result);
    }

    @Test
    public void testGetUserException() {
        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.getUser(1L));
    }

    @Test
    public void testGetUserByEmailException() {
        when(userRepository.findByEmail(anyString())).thenReturn(null);

        assertThrows(UserNotFoundException.class, () -> userService.getUserByEmail("test@example.com"));
    }

    @Test
    public void testLoginException() {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("password");
        UserRequest userRequest = new UserRequest();
        userRequest.setEmail("test@example.com");
        userRequest.setPassword("wrongpassword");
        when(userRepository.findByEmail(anyString())).thenReturn(user);

        assertThrows(UserNotFoundException.class, () -> userService.login(userRequest));
    }

    @Test
    public void testCreateUserException() {
        User userRequest = new User();
        userRequest.setEmail("test@example.com");
        userRequest.setPassword("password");
        userRequest.setPhoneNo("1234567890");
        userRequest.setAddress("Test Address");
        when(userRepository.save(any(User.class))).thenThrow(new RuntimeException());

        assertThrows(RuntimeException.class, () -> userService.createUser(userRequest));
    }

    @Test
    public void testUpdateUserException() {
        User user = new User();
        user.setId(1L);
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPhoneNo("1234567890");
        user.setAddress("Test Address");
        User userRequest = new User();
        userRequest.setEmail("updatedtest@example.com");
        userRequest.setPhoneNo("0987654321");
        userRequest.setAddress("Updated Test Address");
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenThrow(new RuntimeException());

        assertThrows(RuntimeException.class, () -> userService.updateUser(1L, userRequest));
    }

    @Test
    public void testDeleteUserException() {
        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.deleteUser(1L));
    }
}