package com.cognizant.SecondHandBookStore.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.cognizant.SecondHandBookStore.filter.JwtAuthorizationFilter;


/**
 * Configuration class for setting up security configurations in the application.
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
	
	




	private JwtAuthorizationFilter jwtAuthorizationFilter;
	
	
	  /**
     * Constructs a new SecurityConfig object.
     * 
     * @param jwtAuthorizationFilter The JWT authorization filter to be injected.
     */
	public SecurityConfig(JwtAuthorizationFilter jwtAuthorizationFilter) {
		super();
		this.jwtAuthorizationFilter = jwtAuthorizationFilter;
	}
	
	
	
	/**
     * Configures the security filter chain.
     * 
     * @param http The HttpSecurity object to configure security settings.
     * @return The configured SecurityFilterChain.
     * @throws Exception If an error occurs while configuring security.
     */
	@Bean
	    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
        		.cors().and()
                .csrf((csrf) -> csrf.disable())
                .authorizeRequests((auth) -> auth
                        .requestMatchers("/api/v1/user/sign-up", "/api/v1/user/sign-in").permitAll()
                        .anyRequest().authenticated())
                .addFilterBefore(jwtAuthorizationFilter, FilterSecurityInterceptor.class)
                .formLogin(login -> login.disable());
	       return http.build();

	    }
	
	  /**
     * Configures the password encoder bean for password hashing.
     * 
     * @return The PasswordEncoder bean.
     */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	
	
	  /**
     * Configures the CORS (Cross-Origin Resource Sharing) configuration source.
     * 
     * @return The UrlBasedCorsConfigurationSource object with CORS configuration.
     */
	@Bean
	UrlBasedCorsConfigurationSource corsConfigurationSource() {
	    CorsConfiguration configuration = new CorsConfiguration();
	    configuration.setAllowedOrigins(Arrays.asList("*"));
	    configuration.setAllowedMethods(Arrays.asList("*"));
	    configuration.setAllowedHeaders(Arrays.asList("*"));
	    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    source.registerCorsConfiguration("/**", configuration);
	    return source;
	}
	

}
