package com.cognizant.SecondHandBookStore.service;

public class CustomUserDetailService {

}
