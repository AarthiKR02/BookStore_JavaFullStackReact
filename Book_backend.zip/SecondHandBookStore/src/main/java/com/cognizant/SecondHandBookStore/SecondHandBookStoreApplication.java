package com.cognizant.SecondHandBookStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondHandBookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondHandBookStoreApplication.class, args);
	}
}
