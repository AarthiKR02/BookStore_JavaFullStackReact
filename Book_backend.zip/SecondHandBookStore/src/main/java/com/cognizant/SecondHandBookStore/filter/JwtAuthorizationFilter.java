package com.cognizant.SecondHandBookStore.filter;

import java.io.IOException;
import java.util.Collections;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.cognizant.SecondHandBookStore.util.JwtUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
 
@Component
public class JwtAuthorizationFilter extends OncePerRequestFilter{
 
	@Autowired
	private JwtUtil jwtUtil;

	 protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
	            throws ServletException, IOException {

		 
		 
//		 if ("OPTIONS".equals(request.getMethod())) {
//	            response.setStatus(HttpServletResponse.SC_OK);
//	            return;
//	        }
	        String authorizationHeader = request.getHeader("Authorization");

	        if(authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
	        	 String token = authorizationHeader.substring(7);
	        	 if (jwtUtil.validateToken(token)) {
	                 String role = jwtUtil.decodeRoleFromJWTtoken(token);
	                 SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + role);
	                 UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null,
	                         null, Collections.singletonList(authority));
	                 SecurityContextHolder.getContext().setAuthentication(authentication);
	        	 }
	        }
 
		 
		    filterChain.doFilter(request, response);
 
		 
	 }
 
	

	}

