package com.cognizant.SecondHandBookStore.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.SecondHandBookStore.entity.Cart;
import com.cognizant.SecondHandBookStore.exception.ProductOutOfStockException;
import com.cognizant.SecondHandBookStore.responseAndRequest.CartRequest;
import com.cognizant.SecondHandBookStore.service.CartService;

import jakarta.validation.Valid;


/**
 * Controller class for handling cart-related operations.
 */
@RestController
@RequestMapping(path = "/api/v1/cart/")
public class CartController {
	
	
	 //@Autowired to inject an instance of the CartService class
	@Autowired
	private CartService cartService;
	
	 
	
	Logger logger = LoggerFactory.getLogger(CartController.class);
	
	 /**
     * Retrieves cart details by cart ID.
     * 
     * @param id The ID of the cart.
     * @return The Cart object associated with the given ID.
     */
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@GetMapping(path = "/{id}")
	public Cart getCart(@PathVariable Long id) {
		logger.info("getting the Cart Details By cart Id");
		return cartService.getCart(id);
	}
	
	
	
	
	
	
	/**
     * Retrieves cart details by user ID.
     * 
     * @param id The ID of the user.
     * @return The Cart object associated with the given user ID.
     */
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@GetMapping(path = "/user-id/{id}")
	public Cart getCartByUserId(@PathVariable Long id) {
		logger.info("getting the Cart Details By User Id");
		return cartService.getCartByUser(id);
	}
	
	
	
	
	 /**
     * Adds a product item to the cart.
     * 
     * @param cartRequest The request object containing cart details.
     * @return The updated Cart object after adding the product.
     */
	@PreAuthorize("hasRole('ROLE_USER')")
	@PostMapping(path ="/add-to-cart")
	public ResponseEntity<?> addCartItem(@Valid @RequestBody CartRequest cartRequest) {
		
		try {
			logger.info("Adding the product into the cart");
			return ResponseEntity.ok().body(cartService.addCartItem(cartRequest));

		} catch (ProductOutOfStockException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product out of stock");
		}
		catch (Exception e) {
			return ResponseEntity.badRequest().body("Something went wrong!");
		}
		
	}
	
	
	
	 /**
     * Increases the quantity of a product in the cart.
     * 
     * @param productId The ID of the product.
     * @param userId The ID of the user.
     * @return The updated Cart object after increasing the quantity.
     */
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@PutMapping(path = "/increase-quantity/{productId}/{userId}")
	public ResponseEntity<?> increaseQuantityOfProduct(@PathVariable Long productId,@PathVariable Long userId) {
		
		try {
			logger.info("Increasing the quantity of the product in Cart");
			return ResponseEntity.ok().body(cartService.increaseQuantity(productId, userId));
			
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
		
		
	}
	
	
	
	  /**
     * Decreases the quantity of a product in the cart.
     * 
     * @param productId The ID of the product.
     * @param userId The ID of the user.
     * @return The updated Cart object after decreasing the quantity.
     */
	
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@PutMapping(path = "/descrease-quantity/{productId}/{userId}")
	public Cart decreaseQuantityOfProduct(@PathVariable Long productId,@PathVariable Long userId) {
		logger.info("Decreasing the quantity of the product in Cart");
		return cartService.decreaseQuantity(productId, userId);
		
	}
	
	 /**
     * Removes a product from the cart.
     * 
     * @param productId The ID of the product.
     * @param userId The ID of the user.
     * @return The updated Cart object after removing the product.
     */
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@DeleteMapping(path = "/remove-book/{productId}/{userId}")
	public Cart removeBook(@PathVariable Long productId, @PathVariable Long userId) {
		logger.info("Removing the product form Cart");
		return cartService.removeProduct(productId, userId);
	}

}
